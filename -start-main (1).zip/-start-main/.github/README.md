![Super-Music](https://graph.org/file/6e5004198c3bdbba84bdc.jpg)
تنصيب بوتات القرآن الكريم

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=WELCOME+TO+SOURCE-SPIDER+AN+ADVANCE+BOT)](https://github.com/FM8Y/Super-Music)

<p align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</p>

</h3>
<p align="center">
<a href="https://telegram.me/EE_47"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<p align="center">
<a href="https://telegram.me/EE_20"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

تم تطوير و تعريب الملف بواسطة [OSAMA](https://t.me/WWWL5)

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"> <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">




─「 [SOURCE SPIDER](https://t.me/EE_20) 」─ 


  الــمــلــف بــحــقــوق ســورس [ســبــايــدر](https://t.me/EE_20)

غـيـر مـسـمـوح بـتـغـيـيـر حـقـوق [الـمـلـف](https://t.me/EE_20)


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"> <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

